-- FlavorBook Database Schema

-- Create Tags table (predefined dietary tags)
CREATE TABLE Tags (
    Id INTEGER PRIMARY KEY AUTOINCREMENT,
    Name TEXT NOT NULL UNIQUE
);

-- Create Recipes table
CREATE TABLE Recipes (
    Id INTEGER PRIMARY KEY AUTOINCREMENT,
    Name TEXT NOT NULL,
    Origin TEXT NOT NULL,
    CreatedBy TEXT NOT NULL,
    PrepTime INTEGER NOT NULL, -- in minutes
    Body TEXT NOT NULL,
    CreatedAt DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Create Ingredients table
CREATE TABLE Ingredients (
    Id INTEGER PRIMARY KEY AUTOINCREMENT,
    Name TEXT NOT NULL UNIQUE, -- stored in lowercase
    Quantity TEXT, -- optional, e.g., "2" or "1/2"
    Unit TEXT -- optional, e.g., "cups", "tablespoons", "grams"
);

-- Create RecipeTags junction table
CREATE TABLE RecipeTags (
    RecipeId INTEGER NOT NULL,
    TagId INTEGER NOT NULL,
    PRIMARY KEY (RecipeId, TagId),
    FOREIGN KEY (RecipeId) REFERENCES Recipes(Id) ON DELETE CASCADE,
    FOREIGN KEY (TagId) REFERENCES Tags(Id) ON DELETE CASCADE
);

-- Create RecipeIngredients junction table
CREATE TABLE RecipeIngredients (
    RecipeId INTEGER NOT NULL,
    IngredientId INTEGER NOT NULL,
    PRIMARY KEY (RecipeId, IngredientId),
    FOREIGN KEY (RecipeId) REFERENCES Recipes(Id) ON DELETE CASCADE,
    FOREIGN KEY (IngredientId) REFERENCES Ingredients(Id) ON DELETE CASCADE
);

-- Create indexes for better query performance
CREATE INDEX idx_recipes_origin ON Recipes(Origin);
CREATE INDEX idx_recipes_created_at ON Recipes(CreatedAt);
CREATE INDEX idx_recipe_tags_recipe_id ON RecipeTags(RecipeId);
CREATE INDEX idx_recipe_tags_tag_id ON RecipeTags(TagId);
CREATE INDEX idx_recipe_ingredients_recipe_id ON RecipeIngredients(RecipeId);
CREATE INDEX idx_recipe_ingredients_ingredient_id ON RecipeIngredients(IngredientId);

-- Seed dietary tags
INSERT INTO Tags (Name) VALUES ('Vegan');
INSERT INTO Tags (Name) VALUES ('Vegetarian');
INSERT INTO Tags (Name) VALUES ('Gluten-Free');
INSERT INTO Tags (Name) VALUES ('Dairy-Free');
