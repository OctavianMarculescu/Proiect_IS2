using Microsoft.AspNetCore.Mvc;
using FlavorBook.DataTransferObjects;
using FlavorBook.Services.Abstractions;
using FlavorBook.Database.Models;

namespace FlavorBook.Controllers;

[ApiController]
[Route("api/[controller]")]
public class IngredientsController : ControllerBase
{
    private readonly IIngredientService _ingredientService;

    public IngredientsController(IIngredientService ingredientService)
    {
        _ingredientService = ingredientService;
    }

    /// <summary>
    /// Get all ingredients.
    /// </summary>
    [HttpGet]
    public async Task<ActionResult<List<IngredientDto>>> GetIngredients()
    {
        var ingredients = await _ingredientService.GetAllIngredientsAsync();
        var ingredientDtos = ingredients.Select(i => MapToIngredientDto(i)).ToList();
        return Ok(ingredientDtos);
    }

    /// <summary>
    /// Get an ingredient by its ID.
    /// </summary>
    [HttpGet("{id}")]
    public async Task<ActionResult<IngredientDto>> GetIngredientById(int id)
    {
        var ingredient = await _ingredientService.GetIngredientByIdAsync(id);
        if (ingredient == null)
        {
            return NotFound(new { message = $"Ingredient with ID {id} not found." });
        }

        return Ok(MapToIngredientDto(ingredient));
    }

    /// <summary>
    /// Create a new ingredient.
    /// </summary>
    [HttpPost]
    public async Task<ActionResult<IngredientDto>> CreateIngredient([FromBody] CreateIngredientDto createIngredientDto)
    {
        if (!ModelState.IsValid)
        {
            return BadRequest(ModelState);
        }

        var ingredient = await _ingredientService.CreateIngredientAsync(
            createIngredientDto.Name,
            createIngredientDto.Quantity,
            createIngredientDto.Unit);

        return CreatedAtAction(nameof(GetIngredientById), new { id = ingredient.Id }, MapToIngredientDto(ingredient));
    }

    /// <summary>
    /// Update an existing ingredient.
    /// </summary>
    [HttpPut("{id}")]
    public async Task<ActionResult<IngredientDto>> UpdateIngredient(int id, [FromBody] UpdateIngredientDto updateIngredientDto)
    {
        if (!ModelState.IsValid)
        {
            return BadRequest(ModelState);
        }

        try
        {
            var ingredient = await _ingredientService.UpdateIngredientAsync(
                id,
                updateIngredientDto.Name,
                updateIngredientDto.Quantity,
                updateIngredientDto.Unit);

            return Ok(MapToIngredientDto(ingredient));
        }
        catch (KeyNotFoundException)
        {
            return NotFound(new { message = $"Ingredient with ID {id} not found." });
        }
    }

    /// <summary>
    /// Delete an ingredient by its ID.
    /// </summary>
    [HttpDelete("{id}")]
    public async Task<IActionResult> DeleteIngredient(int id)
    {
        var deleted = await _ingredientService.DeleteIngredientAsync(id);
        if (!deleted)
        {
            return NotFound(new { message = $"Ingredient with ID {id} not found." });
        }

        return NoContent();
    }

    private IngredientDto MapToIngredientDto(Ingredient ingredient)
    {
        return new IngredientDto
        {
            Id = ingredient.Id,
            Name = ingredient.Name,
            Quantity = ingredient.Quantity,
            Unit = ingredient.Unit
        };
    }
}
