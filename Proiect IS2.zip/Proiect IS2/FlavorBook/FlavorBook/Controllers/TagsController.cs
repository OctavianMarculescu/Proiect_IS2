using Microsoft.AspNetCore.Mvc;
using FlavorBook.DataTransferObjects;
using FlavorBook.Services.Abstractions;
using FlavorBook.Database.Models;

namespace FlavorBook.Controllers;

[ApiController]
[Route("api/[controller]")]
public class TagsController : ControllerBase
{
    private readonly ITagService _tagService;

    public TagsController(ITagService tagService)
    {
        _tagService = tagService;
    }

    /// <summary>
    /// Get all tags.
    /// </summary>
    [HttpGet]
    public async Task<ActionResult<List<TagDto>>> GetTags()
    {
        var tags = await _tagService.GetAllTagsAsync();
        var tagDtos = tags.Select(t => MapToTagDto(t)).ToList();
        return Ok(tagDtos);
    }

    /// <summary>
    /// Get a tag by its ID.
    /// </summary>
    [HttpGet("{id}")]
    public async Task<ActionResult<TagDto>> GetTagById(int id)
    {
        var tag = await _tagService.GetTagByIdAsync(id);
        if (tag == null)
        {
            return NotFound(new { message = $"Tag with ID {id} not found." });
        }

        return Ok(MapToTagDto(tag));
    }

    /// <summary>
    /// Create a new tag.
    /// </summary>
    [HttpPost]
    public async Task<ActionResult<TagDto>> CreateTag([FromBody] CreateTagDto createTagDto)
    {
        if (!ModelState.IsValid)
        {
            return BadRequest(ModelState);
        }

        var tag = await _tagService.CreateTagAsync(createTagDto.Name);

        return CreatedAtAction(nameof(GetTagById), new { id = tag.Id }, MapToTagDto(tag));
    }

    /// <summary>
    /// Update an existing tag.
    /// </summary>
    [HttpPut("{id}")]
    public async Task<ActionResult<TagDto>> UpdateTag(int id, [FromBody] CreateTagDto updateTagDto)
    {
        if (!ModelState.IsValid)
        {
            return BadRequest(ModelState);
        }

        try
        {
            var tag = await _tagService.UpdateTagAsync(id, updateTagDto.Name);

            return Ok(MapToTagDto(tag));
        }
        catch (KeyNotFoundException)
        {
            return NotFound(new { message = $"Tag with ID {id} not found." });
        }
    }

    /// <summary>
    /// Delete a tag by its ID.
    /// </summary>
    [HttpDelete("{id}")]
    public async Task<IActionResult> DeleteTag(int id)
    {
        var deleted = await _tagService.DeleteTagAsync(id);
        if (!deleted)
        {
            return NotFound(new { message = $"Tag with ID {id} not found." });
        }

        return NoContent();
    }

    private TagDto MapToTagDto(Tag tag)
    {
        return new TagDto
        {
            Id = tag.Id,
            Name = tag.Name
        };
    }
}
