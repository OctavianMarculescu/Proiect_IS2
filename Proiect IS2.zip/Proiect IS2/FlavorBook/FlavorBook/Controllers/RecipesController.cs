using Microsoft.AspNetCore.Mvc;
using FlavorBook.DataTransferObjects;
using FlavorBook.Services.Abstractions;
using FlavorBook.Database.Models;

namespace FlavorBook.Controllers;

[ApiController]
[Route("api/[controller]")]
public class RecipesController : ControllerBase
{
    private readonly IRecipeService _recipeService;

    public RecipesController(IRecipeService recipeService)
    {
        _recipeService = recipeService;
    }

    /// <summary>
    /// Get all recipes with optional filtering, searching, and pagination.
    /// </summary>
    [HttpGet]
    public async Task<ActionResult<PaginatedResultDto<RecipeDto>>> GetRecipes(
        [FromQuery] int pageNumber = 1,
        [FromQuery] int pageSize = 10,
        [FromQuery] string? origin = null,
        [FromQuery] string? ingredientName = null,
        [FromQuery] string? searchName = null)
    {
        var (recipes, totalCount) = await _recipeService.GetAllRecipesAsync(
            pageNumber,
            pageSize,
            origin,
            ingredientName,
            searchName);

        var recipeDtos = recipes.Select(r => MapToRecipeDto(r)).ToList();

        var result = new PaginatedResultDto<RecipeDto>
        {
            Items = recipeDtos,
            TotalCount = totalCount,
            PageNumber = pageNumber,
            PageSize = pageSize
        };

        return Ok(result);
    }

    /// <summary>
    /// Get a recipe by its ID.
    /// </summary>
    [HttpGet("{id}")]
    public async Task<ActionResult<RecipeDto>> GetRecipeById(int id)
    {
        var recipe = await _recipeService.GetRecipeByIdAsync(id);
        if (recipe == null)
        {
            return NotFound(new { message = $"Recipe with ID {id} not found." });
        }

        return Ok(MapToRecipeDto(recipe));
    }

    /// <summary>
    /// Create a new recipe.
    /// </summary>
    [HttpPost]
    public async Task<ActionResult<RecipeDto>> CreateRecipe([FromBody] CreateRecipeDto createRecipeDto)
    {
        if (!ModelState.IsValid)
        {
            return BadRequest(ModelState);
        }

        var recipe = await _recipeService.CreateRecipeAsync(
            createRecipeDto.Name,
            createRecipeDto.Origin,
            createRecipeDto.CreatedBy,
            createRecipeDto.PrepTime,
            createRecipeDto.Body,
            createRecipeDto.IngredientNames,
            createRecipeDto.TagIds);

        return CreatedAtAction(nameof(GetRecipeById), new { id = recipe.Id }, MapToRecipeDto(recipe));
    }

    /// <summary>
    /// Update an existing recipe.
    /// </summary>
    [HttpPut("{id}")]
    public async Task<ActionResult<RecipeDto>> UpdateRecipe(int id, [FromBody] UpdateRecipeDto updateRecipeDto)
    {
        if (!ModelState.IsValid)
        {
            return BadRequest(ModelState);
        }

        try
        {
            var recipe = await _recipeService.UpdateRecipeAsync(
                id,
                updateRecipeDto.Name,
                updateRecipeDto.Origin,
                updateRecipeDto.CreatedBy,
                updateRecipeDto.PrepTime,
                updateRecipeDto.Body);

            return Ok(MapToRecipeDto(recipe));
        }
        catch (KeyNotFoundException)
        {
            return NotFound(new { message = $"Recipe with ID {id} not found." });
        }
    }

    /// <summary>
    /// Delete a recipe by its ID.
    /// </summary>
    [HttpDelete("{id}")]
    public async Task<IActionResult> DeleteRecipe(int id)
    {
        var deleted = await _recipeService.DeleteRecipeAsync(id);
        if (!deleted)
        {
            return NotFound(new { message = $"Recipe with ID {id} not found." });
        }

        return NoContent();
    }

    private RecipeDto MapToRecipeDto(Recipe recipe)
    {
        return new RecipeDto
        {
            Id = recipe.Id,
            Name = recipe.Name,
            Origin = recipe.Origin,
            CreatedBy = recipe.CreatedBy,
            PrepTime = recipe.PrepTime,
            Body = recipe.Body,
            CreatedAt = recipe.CreatedAt,
            Ingredients = recipe.Ingredients.Select(i => new IngredientDto
            {
                Id = i.Id,
                Name = i.Name,
                Quantity = i.Quantity,
                Unit = i.Unit
            }).ToList(),
            Tags = recipe.Tags.Select(t => new TagDto
            {
                Id = t.Id,
                Name = t.Name
            }).ToList()
        };
    }
}
