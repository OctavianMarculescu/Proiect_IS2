namespace FlavorBook.DataTransferObjects;

/// <summary>
/// DTO for creating a new ingredient.
/// </summary>
public class CreateIngredientDto
{
    public string Name { get; set; } = null!;
    public string? Quantity { get; set; }
    public string? Unit { get; set; }
}
