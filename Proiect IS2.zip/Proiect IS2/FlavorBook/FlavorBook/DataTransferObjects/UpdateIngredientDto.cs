namespace FlavorBook.DataTransferObjects;

/// <summary>
/// DTO for updating an ingredient.
/// </summary>
public class UpdateIngredientDto
{
    public string? Name { get; set; }
    public string? Quantity { get; set; }
    public string? Unit { get; set; }
}
