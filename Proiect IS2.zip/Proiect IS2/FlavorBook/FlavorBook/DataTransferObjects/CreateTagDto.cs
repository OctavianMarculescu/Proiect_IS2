namespace FlavorBook.DataTransferObjects;

/// <summary>
/// DTO for creating a new tag.
/// </summary>
public class CreateTagDto
{
    public string Name { get; set; } = null!;
}
