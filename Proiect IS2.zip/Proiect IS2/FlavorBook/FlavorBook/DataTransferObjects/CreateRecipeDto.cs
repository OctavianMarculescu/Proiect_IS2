namespace FlavorBook.DataTransferObjects;

/// <summary>
/// DTO for creating a new recipe.
/// </summary>
public class CreateRecipeDto
{
    public string Name { get; set; } = null!;
    public string Origin { get; set; } = null!;
    public string CreatedBy { get; set; } = null!;
    public int PrepTime { get; set; }
    public string Body { get; set; } = null!;
    public List<string> IngredientNames { get; set; } = new();
    public List<int> TagIds { get; set; } = new();
}
