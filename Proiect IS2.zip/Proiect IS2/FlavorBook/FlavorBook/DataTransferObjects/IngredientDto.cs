namespace FlavorBook.DataTransferObjects;

/// <summary>
/// DTO for ingredient data.
/// </summary>
public class IngredientDto
{
    public int Id { get; set; }
    public string Name { get; set; } = null!;
    public string? Quantity { get; set; }
    public string? Unit { get; set; }
}
