namespace FlavorBook.DataTransferObjects;

/// <summary>
/// DTO for updating an existing recipe.
/// </summary>
public class UpdateRecipeDto
{
    public string? Name { get; set; }
    public string? Origin { get; set; }
    public string? CreatedBy { get; set; }
    public int? PrepTime { get; set; }
    public string? Body { get; set; }
}
