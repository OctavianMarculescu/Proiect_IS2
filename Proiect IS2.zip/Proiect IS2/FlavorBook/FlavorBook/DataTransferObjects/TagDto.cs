namespace FlavorBook.DataTransferObjects;

/// <summary>
/// DTO for tag data.
/// </summary>
public class TagDto
{
    public int Id { get; set; }
    public string Name { get; set; } = null!;
}
