namespace FlavorBook.DataTransferObjects;

/// <summary>
/// DTO for recipe read operations.
/// </summary>
public class RecipeDto
{
    public int Id { get; set; }
    public string Name { get; set; } = null!;
    public string Origin { get; set; } = null!;
    public string CreatedBy { get; set; } = null!;
    public int PrepTime { get; set; }
    public string Body { get; set; } = null!;
    public DateTime CreatedAt { get; set; }
    public List<IngredientDto> Ingredients { get; set; } = new();
    public List<TagDto> Tags { get; set; } = new();
}
