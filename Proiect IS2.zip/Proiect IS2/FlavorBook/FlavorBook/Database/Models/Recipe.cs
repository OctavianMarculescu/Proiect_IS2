﻿using System;
using System.Collections.Generic;

namespace FlavorBook.Database.Models;

public partial class Recipe
{
    public int Id { get; set; }

    public string Name { get; set; } = null!;

    public string Origin { get; set; } = null!;

    public string CreatedBy { get; set; } = null!;

    public int PrepTime { get; set; }

    public string Body { get; set; } = null!;

    public DateTime CreatedAt { get; set; }

    public virtual ICollection<Ingredient> Ingredients { get; set; } = new List<Ingredient>();

    public virtual ICollection<Tag> Tags { get; set; } = new List<Tag>();
}
