﻿using System;
using System.Collections.Generic;
using FlavorBook.Database.Models;
using Microsoft.EntityFrameworkCore;

namespace FlavorBook.Database;

public partial class FlavorBookDatabaseContext : DbContext
{
    public FlavorBookDatabaseContext()
    {
    }

    public FlavorBookDatabaseContext(DbContextOptions<FlavorBookDatabaseContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Ingredient> Ingredients { get; set; }

    public virtual DbSet<Recipe> Recipes { get; set; }

    public virtual DbSet<Tag> Tags { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        var dataSource = Environment.GetEnvironmentVariable("DATABASE_PATH") ?? "FlavorBook.db";
        optionsBuilder.UseSqlite($"Data Source={dataSource}");
    }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Ingredient>(entity =>
        {
            entity.HasIndex(e => e.Name, "IX_Ingredients_Name").IsUnique();
        });

        modelBuilder.Entity<Recipe>(entity =>
        {
            entity.HasIndex(e => e.CreatedAt, "idx_recipes_created_at");

            entity.HasIndex(e => e.Origin, "idx_recipes_origin");

            entity.Property(e => e.CreatedAt)
                .HasDefaultValueSql("CURRENT_TIMESTAMP")
                .HasColumnType("DATETIME");

            entity.HasMany(d => d.Ingredients).WithMany(p => p.Recipes)
                .UsingEntity<Dictionary<string, object>>(
                    "RecipeIngredient",
                    r => r.HasOne<Ingredient>().WithMany().HasForeignKey("IngredientId"),
                    l => l.HasOne<Recipe>().WithMany().HasForeignKey("RecipeId"),
                    j =>
                    {
                        j.HasKey("RecipeId", "IngredientId");
                        j.ToTable("RecipeIngredients");
                        j.HasIndex(new[] { "IngredientId" }, "idx_recipe_ingredients_ingredient_id");
                        j.HasIndex(new[] { "RecipeId" }, "idx_recipe_ingredients_recipe_id");
                    });

            entity.HasMany(d => d.Tags).WithMany(p => p.Recipes)
                .UsingEntity<Dictionary<string, object>>(
                    "RecipeTag",
                    r => r.HasOne<Tag>().WithMany().HasForeignKey("TagId"),
                    l => l.HasOne<Recipe>().WithMany().HasForeignKey("RecipeId"),
                    j =>
                    {
                        j.HasKey("RecipeId", "TagId");
                        j.ToTable("RecipeTags");
                        j.HasIndex(new[] { "RecipeId" }, "idx_recipe_tags_recipe_id");
                        j.HasIndex(new[] { "TagId" }, "idx_recipe_tags_tag_id");
                    });
        });

        modelBuilder.Entity<Tag>(entity =>
        {
            entity.HasIndex(e => e.Name, "IX_Tags_Name").IsUnique();
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
