using FlavorBook.Database.Models;

namespace FlavorBook.Services.Abstractions;

public interface IIngredientService
{
    /// <summary>
    /// Get all ingredients.
    /// </summary>
    Task<List<Ingredient>> GetAllIngredientsAsync();

    /// <summary>
    /// Get an ingredient by its ID.
    /// </summary>
    Task<Ingredient?> GetIngredientByIdAsync(int id);

    /// <summary>
    /// Get or create an ingredient by name (stored in lowercase).
    /// </summary>
    Task<Ingredient> GetOrCreateIngredientAsync(string name);

    /// <summary>
    /// Create a new ingredient.
    /// </summary>
    Task<Ingredient> CreateIngredientAsync(string name, string? quantity = null, string? unit = null);

    /// <summary>
    /// Update an existing ingredient.
    /// </summary>
    Task<Ingredient> UpdateIngredientAsync(int id, string? name = null, string? quantity = null, string? unit = null);

    /// <summary>
    /// Delete an ingredient by its ID.
    /// </summary>
    Task<bool> DeleteIngredientAsync(int id);
}
