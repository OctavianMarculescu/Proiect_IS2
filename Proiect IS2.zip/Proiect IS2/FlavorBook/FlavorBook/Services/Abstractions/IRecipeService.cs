using FlavorBook.Database.Models;

namespace FlavorBook.Services.Abstractions;

public interface IRecipeService
{
    /// <summary>
    /// Get all recipes with optional filtering, searching, and pagination.
    /// </summary>
    Task<(List<Recipe> Recipes, int TotalCount)> GetAllRecipesAsync(
        int pageNumber = 1,
        int pageSize = 10,
        string? origin = null,
        string? ingredientName = null,
        string? searchName = null);

    /// <summary>
    /// Get a recipe by its ID.
    /// </summary>
    Task<Recipe?> GetRecipeByIdAsync(int id);

    /// <summary>
    /// Create a new recipe with ingredients and tags.
    /// </summary>
    Task<Recipe> CreateRecipeAsync(
        string name,
        string origin,
        string createdBy,
        int prepTime,
        string body,
        List<string>? ingredientNames = null,
        List<int>? tagIds = null);

    /// <summary>
    /// Update an existing recipe.
    /// </summary>
    Task<Recipe> UpdateRecipeAsync(
        int id,
        string? name = null,
        string? origin = null,
        string? createdBy = null,
        int? prepTime = null,
        string? body = null);

    /// <summary>
    /// Delete a recipe by its ID.
    /// </summary>
    Task<bool> DeleteRecipeAsync(int id);
}
