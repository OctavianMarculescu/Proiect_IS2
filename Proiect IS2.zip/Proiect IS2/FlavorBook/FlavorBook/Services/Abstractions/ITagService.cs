using FlavorBook.Database.Models;

namespace FlavorBook.Services.Abstractions;

public interface ITagService
{
    /// <summary>
    /// Get all tags.
    /// </summary>
    Task<List<Tag>> GetAllTagsAsync();

    /// <summary>
    /// Get a tag by its ID.
    /// </summary>
    Task<Tag?> GetTagByIdAsync(int id);

    /// <summary>
    /// Create a new tag.
    /// </summary>
    Task<Tag> CreateTagAsync(string name);

    /// <summary>
    /// Update an existing tag.
    /// </summary>
    Task<Tag> UpdateTagAsync(int id, string name);

    /// <summary>
    /// Delete a tag by its ID.
    /// </summary>
    Task<bool> DeleteTagAsync(int id);
}
