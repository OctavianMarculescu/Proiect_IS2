using Microsoft.EntityFrameworkCore;
using FlavorBook.Database;
using FlavorBook.Database.Models;
using FlavorBook.Services.Abstractions;

namespace FlavorBook.Services.Implementations;

public class IngredientService : IIngredientService
{
    private readonly FlavorBookDatabaseContext _context;

    public IngredientService(FlavorBookDatabaseContext context)
    {
        _context = context;
    }

    public async Task<List<Ingredient>> GetAllIngredientsAsync()
    {
        return await _context.Ingredients.ToListAsync();
    }

    public async Task<Ingredient?> GetIngredientByIdAsync(int id)
    {
        return await _context.Ingredients.FindAsync(id);
    }

    public async Task<Ingredient> GetOrCreateIngredientAsync(string name)
    {
        var normalizedName = name.ToLower().Trim();

        var existingIngredient = await _context.Ingredients
            .FirstOrDefaultAsync(i => i.Name.ToLower() == normalizedName);

        if (existingIngredient != null)
        {
            return existingIngredient;
        }

        return await CreateIngredientAsync(normalizedName);
    }

    public async Task<Ingredient> CreateIngredientAsync(string name, string? quantity = null, string? unit = null)
    {
        var normalizedName = name.ToLower().Trim();

        // Check if ingredient already exists
        var existingIngredient = await _context.Ingredients
            .FirstOrDefaultAsync(i => i.Name.ToLower() == normalizedName);

        if (existingIngredient != null)
        {
            return existingIngredient;
        }

        var ingredient = new Ingredient
        {
            Name = normalizedName,
            Quantity = quantity?.Trim(),
            Unit = unit?.Trim()
        };

        _context.Ingredients.Add(ingredient);
        await _context.SaveChangesAsync();

        return ingredient;
    }

    public async Task<Ingredient> UpdateIngredientAsync(int id, string? name = null, string? quantity = null, string? unit = null)
    {
        var ingredient = await _context.Ingredients.FindAsync(id);
        if (ingredient == null)
        {
            throw new KeyNotFoundException($"Ingredient with ID {id} not found.");
        }

        if (!string.IsNullOrWhiteSpace(name))
            ingredient.Name = name.ToLower().Trim();

        if (quantity != null)
            ingredient.Quantity = quantity.Trim();

        if (unit != null)
            ingredient.Unit = unit.Trim();

        _context.Ingredients.Update(ingredient);
        await _context.SaveChangesAsync();

        return ingredient;
    }

    public async Task<bool> DeleteIngredientAsync(int id)
    {
        var ingredient = await _context.Ingredients.FindAsync(id);
        if (ingredient == null)
        {
            return false;
        }

        _context.Ingredients.Remove(ingredient);
        await _context.SaveChangesAsync();

        return true;
    }
}
