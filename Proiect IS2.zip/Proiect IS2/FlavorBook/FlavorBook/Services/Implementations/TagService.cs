using Microsoft.EntityFrameworkCore;
using FlavorBook.Database;
using FlavorBook.Database.Models;
using FlavorBook.Services.Abstractions;

namespace FlavorBook.Services.Implementations;

public class TagService : ITagService
{
    private readonly FlavorBookDatabaseContext _context;

    public TagService(FlavorBookDatabaseContext context)
    {
        _context = context;
    }

    public async Task<List<Tag>> GetAllTagsAsync()
    {
        return await _context.Tags.ToListAsync();
    }

    public async Task<Tag?> GetTagByIdAsync(int id)
    {
        return await _context.Tags.FindAsync(id);
    }

    public async Task<Tag> CreateTagAsync(string name)
    {
        var tag = new Tag
        {
            Name = name
        };

        _context.Tags.Add(tag);
        await _context.SaveChangesAsync();

        return tag;
    }

    public async Task<Tag> UpdateTagAsync(int id, string name)
    {
        var tag = await _context.Tags.FindAsync(id);
        if (tag == null)
        {
            throw new KeyNotFoundException($"Tag with ID {id} not found.");
        }

        tag.Name = name;

        _context.Tags.Update(tag);
        await _context.SaveChangesAsync();

        return tag;
    }

    public async Task<bool> DeleteTagAsync(int id)
    {
        var tag = await _context.Tags.FindAsync(id);
        if (tag == null)
        {
            return false;
        }

        _context.Tags.Remove(tag);
        await _context.SaveChangesAsync();

        return true;
    }
}
