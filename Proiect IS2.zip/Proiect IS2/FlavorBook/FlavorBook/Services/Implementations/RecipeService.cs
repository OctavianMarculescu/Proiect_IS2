using Microsoft.EntityFrameworkCore;
using FlavorBook.Database;
using FlavorBook.Database.Models;
using FlavorBook.Services.Abstractions;

namespace FlavorBook.Services.Implementations;

public class RecipeService : IRecipeService
{
    private readonly FlavorBookDatabaseContext _context;
    private readonly IIngredientService _ingredientService;

    public RecipeService(FlavorBookDatabaseContext context, IIngredientService ingredientService)
    {
        _context = context;
        _ingredientService = ingredientService;
    }

    public async Task<(List<Recipe> Recipes, int TotalCount)> GetAllRecipesAsync(
        int pageNumber = 1,
        int pageSize = 10,
        string? origin = null,
        string? ingredientName = null,
        string? searchName = null)
    {
        var query = _context.Recipes.AsQueryable();

        // Filter by origin
        if (!string.IsNullOrWhiteSpace(origin))
        {
            query = query.Where(r => r.Origin.ToLower() == origin.ToLower());
        }

        // Filter by ingredient name
        if (!string.IsNullOrWhiteSpace(ingredientName))
        {
            query = query.Where(r => r.Ingredients
                .Any(i => i.Name.ToLower() == ingredientName.ToLower()));
        }

        // Search by recipe name
        if (!string.IsNullOrWhiteSpace(searchName))
        {
            query = query.Where(r => r.Name.ToLower().Contains(searchName.ToLower()));
        }

        // Get total count before pagination
        var totalCount = await query.CountAsync();

        // Apply pagination
        var recipes = await query
            .OrderByDescending(r => r.CreatedAt)
            .Skip((pageNumber - 1) * pageSize)
            .Take(pageSize)
            .Include(r => r.Ingredients)
            .Include(r => r.Tags)
            .ToListAsync();

        return (recipes, totalCount);
    }

    public async Task<Recipe?> GetRecipeByIdAsync(int id)
    {
        return await _context.Recipes
            .Include(r => r.Ingredients)
            .Include(r => r.Tags)
            .FirstOrDefaultAsync(r => r.Id == id);
    }

    public async Task<Recipe> CreateRecipeAsync(
        string name,
        string origin,
        string createdBy,
        int prepTime,
        string body,
        List<string>? ingredientNames = null,
        List<int>? tagIds = null)
    {
        var recipe = new Recipe
        {
            Name = name,
            Origin = origin,
            CreatedBy = createdBy,
            PrepTime = prepTime,
            Body = body,
            CreatedAt = DateTime.UtcNow
        };

        // Add ingredients
        if (ingredientNames != null && ingredientNames.Any())
        {
            foreach (var ingredientName in ingredientNames)
            {
                var ingredient = await _ingredientService.GetOrCreateIngredientAsync(ingredientName);
                recipe.Ingredients.Add(ingredient);
            }
        }

        // Add tags
        if (tagIds != null && tagIds.Any())
        {
            var tags = await _context.Tags
                .Where(t => tagIds.Contains(t.Id))
                .ToListAsync();
            foreach (var tag in tags)
            {
                recipe.Tags.Add(tag);
            }
        }

        _context.Recipes.Add(recipe);
        await _context.SaveChangesAsync();

        return recipe;
    }

    public async Task<Recipe> UpdateRecipeAsync(
        int id,
        string? name = null,
        string? origin = null,
        string? createdBy = null,
        int? prepTime = null,
        string? body = null)
    {
        var recipe = await _context.Recipes.FindAsync(id);
        if (recipe == null)
        {
            throw new KeyNotFoundException($"Recipe with ID {id} not found.");
        }

        if (!string.IsNullOrWhiteSpace(name))
            recipe.Name = name;

        if (!string.IsNullOrWhiteSpace(origin))
            recipe.Origin = origin;

        if (!string.IsNullOrWhiteSpace(createdBy))
            recipe.CreatedBy = createdBy;

        if (prepTime.HasValue)
            recipe.PrepTime = prepTime.Value;

        if (!string.IsNullOrWhiteSpace(body))
            recipe.Body = body;

        _context.Recipes.Update(recipe);
        await _context.SaveChangesAsync();

        return recipe;
    }

    public async Task<bool> DeleteRecipeAsync(int id)
    {
        var recipe = await _context.Recipes.FindAsync(id);
        if (recipe == null)
        {
            return false;
        }

        _context.Recipes.Remove(recipe);
        await _context.SaveChangesAsync();

        return true;
    }
}
